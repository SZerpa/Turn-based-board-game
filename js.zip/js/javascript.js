                            //Project 6: Build a turn-based board game in JavaScript. JS FILE

/*--------------------------------------------------------------------------------------------
GENERAL PRE-INFORMATION
--------------------------------------------------------------------------------------------*/
//Const and let staments.
const boardSize = 89;
const numObstacles = 10;
let squares = [];
let maxMoves = 3;
let newPos;
let playerActive;
let playerNotActive;
let playerActiveDiv;
let playerNotActiveDiv;
let player1Active = true;
let move = true;
let attacked = false;
let defended = false;
let player1Defended = false;
let player2Defended = false;
let hover = false;
const attackButton = $('.attack');
const defendButton = $('.defend');
const startButton = $('#start');
const playAgainButton = $('#play-again');
const boardGameDiv = $('#board-game');
const gameOverDiv = $('#game-over');
const startGameDiv = $('#start-game');
const playerContainerDiv = $('.player-container');
const body = $('body');
const messageDiv = $('.message');
const message1Div = $('.message1');
const message2Div = $('.message2');
const playerNameDiv = $('.player-name');
const winnerDiv = $('.winner');


/*--------------------------------------------------------------------------------------------
GAME BOARD, PLAYERS AND ALL ELEMENTS
--------------------------------------------------------------------------------------------*/

//Creates functions for game board and obstacles. The game board is created using the html<li> and an algorithm. 
function GameBoard(boardSize) {
    this.boardSize = boardSize;
}

GameBoard.prototype.createBoard = function () {
    for (let i = 0; i <= boardSize; i += 1) {
        boardGameDiv.append('<li class="box" boxID="' + i + '"></li>');
        let numSquares = $('.box').length;
        squares.push(numSquares);
    }
};
GameBoard.prototype.obstacles = function (eachPlayer) {
    addItem(eachPlayer)
};


// Creates the game
let game = new GameBoard(boardSize);

//Creates a function for player, its prototype, and state
function Player(name, score, eachPlayer, player, weapon, damage) {
    this.name = name;
    this.score = score;
    this.eachPlayer = eachPlayer;
    this.player = player;
    this.weapon = weapon;
    this.damage = damage;
}

Player.prototype.add = function () {
    addItem(this.eachPlayer, this.player);
};

function State(active, notActive, attack, win, dead) {
    this.active = active;
    this.notActive = notActive;
    this.attack = attack;
    this.win = win;
    this.dead = dead;
}

//Creates the players
let player1 = new Player('Dorothy', 100, 'player1', 1, '', 0);
let player2 = new Player('The Witch', 100, 'player2', 2, '', 0,);
let player1State = new State('src/player1.png');
let player2State = new State('src/player2.png');


//Creates the data boxes
function setPlayerData(playerDiv, player, weapon) {
    $(playerDiv + ' .player-name').text(player.name);
    $(playerDiv + ' .score').text(player.score);
    $(playerDiv + ' .magicBox').removeClass().addClass('magicBox ' + player.weapon);
    $(playerDiv + ' .weapon-value').text(player.damage);
}

/*--------------------------------------------------------------------------------------------
MOVEMENT OF PLAYERS
--------------------------------------------------------------------------------------------*/

//Move player as needed. Taking obstacles, fight option and weapons into consideration.
function movePlayer() {

    //mouseover the squares
    let boxClass = $('.box');
    boxClass.hover(
        function () {
            hover = true;
            let sqHovered = $(this).attr('boxID');
            newPos = getXYPosition(sqHovered);

            //The squares in the board will be based of x and y values.
            //from x to x
            for (let i = Math.min(oldPos.x, newPos.x); i <= Math.max(oldPos.x, newPos.x); i++) {
                let num = getSquareValue(i, oldPos.y);
                let square = $('.box[boxID = ' + num + ']');
                if (square.hasClass('obstacle')) {
                    return;
                }
                if (player1Active) {
                    if (square.hasClass('player2')) {
                        return;
                    }
                } else {
                    if (square.hasClass('player1')) {
                        return;
                    }
                }
            }

            //from y to y
            for (let i = Math.min(oldPos.y, newPos.y); i <= Math.max(oldPos.y, newPos.y); i++) {
                let num = getSquareValue(oldPos.x, i);
                let square = $('.box[boxID = ' + num + ']');
                if (square.hasClass('obstacle')) {
                    return;
                }
                if (player1Active) {
                    if (square.hasClass('player2')) {
                        return;
                    }
                } else {
                    if (square.hasClass('player1')) {
                        return;
                    }
                }
            }

            //if attacked
            if (!attacked) {
                if (newPos.y === oldPos.y && newPos.x <= oldPos.x + maxMoves && newPos.x >= oldPos.x - maxMoves
                    || newPos.x === oldPos.x && newPos.y <= oldPos.y + maxMoves && newPos.y >= oldPos.y - maxMoves) {

                    if (player1Active) {
                        $(this).css('backgroundImage', 'url(' + player1State.active + ')');

                    } else {
                        $(this).css('backgroundImage', 'url(' + player2State.active + ')');
                    }
                }

            }
        }, 

        // hide character's extra on mouseover
        function () {
            hover = false;
            $(this).css('backgroundImage', '');
        }
    );

    // movement once the position is determined
    boxClass.on('click', function () {
        hover = false;
        let sqClicked = $(this).attr('boxID');
        newPos = getXYPosition(sqClicked);


        //The squares in the board will be based of x and y values.
        //from x to x
        for (let i = Math.min(oldPos.x, newPos.x); i <= Math.max(oldPos.x, newPos.x); i++) {
            let num = getSquareValue(i, oldPos.y);
            let square = $('.box[boxID = ' + num + ']');
            if (square.hasClass('obstacle')) {
                alertMessage(alertMove);
                return;
            }
            if (player1Active) {
                if (square.hasClass('player2')) {
                    alertMessage(alertPlayer);
                    return;
                }
            } else {
                if (square.hasClass('player1')) {
                    alertMessage(alertPlayer);
                    return;
                }
            }
        }

        //from y to y
        for (let i = Math.min(oldPos.y, newPos.y); i <= Math.max(oldPos.y, newPos.y); i++) {
            let num = getSquareValue(oldPos.x, i);
            let square = $('.box[boxID = ' + num + ']');
            if (square.hasClass('obstacle')) {
                alertMessage(alertMove);
                return;
            }

            if (player1Active) {
                if (square.hasClass('player2')) {
                    alertMessage(alertPlayer);
                    return;
                }
            } else {
                if (square.hasClass('player1')) {
                    alertMessage(alertPlayer);
                    return;
                }
            }
        }

        // alert players to move
        if (player1Active) {
            if ($(this).hasClass('player1')){
                alertMessage(alertMustMove);
                return;
            }
        }else{
            if ($(this).hasClass('player2')){
                alertMessage(alertMustMove);
                return;
            }
        }

        // move only the active player and generate message to let know active player it is their turn
        if (move) {
            if (newPos.y === oldPos.y && newPos.x <= oldPos.x + maxMoves && newPos.x >= oldPos.x - maxMoves
                || newPos.x === oldPos.x && newPos.y <= oldPos.y + maxMoves && newPos.y >= oldPos.y - maxMoves) {
                for (let i = Math.min(oldPos.x, newPos.x); i <= Math.max(oldPos.x, newPos.x); i++) {
                    let num = getSquareValue(i, oldPos.y);
                    checkWeapon(num);
                }
                for (let i = Math.min(oldPos.y, newPos.y); i <= Math.max(oldPos.y, newPos.y); i++) {
                    let num = getSquareValue(oldPos.x, i);
                    checkWeapon(num);
                }
                whoIsActive();
                if (player1Active) {
                    playerPosition = getPosition('.player2');
                    oldPos = getXYPosition(playerPosition);
                    $('.player1').removeClass('player1').removeClass('active');
                    $(this).addClass("player1");
                    $('.player2').addClass('active');
                    fight(newPos, oldPos);
                    player1Active = false;
                    $(' .message1').text('Dorothy, it is your turn!');
                    $(' .message2').text('Witch, it is your turn!');
                    $(' .message1').hide();
                    $(' .message2').show();
               }
                else {
                    playerPosition = getPosition('.player1');
                    oldPos = getXYPosition(playerPosition);
                    $('.player2').removeClass('player2').removeClass('active');
                    $(this).addClass("player2");
                    $('.player1').addClass('active');
                    fight(newPos, oldPos);
                    player1Active = true;
                    $(' .message1').text('Dorothy, it is your turn!');
                    $(' .message2').text('Witch, it is your turn!');
                    $(' .message1').show();
                    $(' .message2').hide();
                }
            }
        }
    });
}

//Get active player
function GetPlayerActive(Active, NotActive, ActiveDiv, NotActiveDiv, activeState, notActiveState) {
    playerActive = Active;
    playerNotActive = NotActive;
    playerActiveDiv = ActiveDiv;
    playerNotActiveDiv = NotActiveDiv;
    $(NotActiveDiv + ' .player-state').css('backgroundImage', 'url(' + activeState + ')');
    $(ActiveDiv + ' .player-state').css('backgroundImage', 'url(' + notActiveState + ')');
}

//Set values for active player
function whoIsActive() {
    if (player1Active) {
        GetPlayerActive(player1, player2, '#player-1', '#player-2', player2State.active, player1State.notActive); 
    } else {
        GetPlayerActive(player2, player1, '#player-2', '#player-1', player1State.active, player2State.notActive);
    }
}

/*--------------------------------------------------------------------------------------------
WEAPONS
--------------------------------------------------------------------------------------------*/

//Creates a function for weapon and its prototype
function Weapon(type, value, eachPlayer) {
    this.type = type;
    this.value = value;
    this.eachPlayer = eachPlayer;
}

Weapon.prototype.add = function () {
    addItem(this.eachPlayer);
};

//Create weapons (magic boxes) with their values

let redBox = new Weapon('redBox', 70, 'redBox weapon');
let whiteBox = new Weapon('whiteBox', 60, 'whiteBox weapon');
let greenBox = new Weapon('greenBox', 40, 'greenBox weapon');
let yellowBox = new Weapon('yellowBox', 30, 'yellowBox weapon');
let pinkBox = new Weapon('pinkBox', 20, 'pinkBox weapon');

//Update player's weapons score
function changeWeaponValue(playerDiv, player, weapon) {
    player.damage = weapon.value;
    $(playerDiv + ' .weapon-value').text(player.damage);
}

function removePlayerWeapon(playerActiveDiv, playerActive) {
    $(playerActiveDiv + ' .magicBox').removeClass(playerActive.weapon);
}

function addPlayerWeapon(playerActiveDiv, playerActive) {
    $(playerActiveDiv + ' .magicBox').addClass(playerActive.weapon);
}

//Give needed weapon to the active player that took it and give designated points
function changeWeapon(num, magicBox, weapon) {
    let square = $('.box[boxID = ' + num + ']');
    whoIsActive();
    square.removeClass(magicBox).addClass(playerActive.weapon);
    removePlayerWeapon(playerActiveDiv, playerActive);
    playerActive.weapon = magicBox;
    addPlayerWeapon(playerActiveDiv, playerActive);
    changeWeaponValue(playerActiveDiv, playerActive, weapon, weapon.value);
}

function extraPoints(playerActive, playerActiveDiv, item, eachPlayer, gain, text1, text2) {
    if (gain) {
        playerActive.score = playerActive.score + item.value;
    } else {
        playerActive.score = playerActive.score - item.value;
    }
    $(playerActiveDiv + ' .score').text(playerActive.score);
    $('.' + eachPlayer).removeClass(eachPlayer + ' weapon');
    $(playerActiveDiv + ' .message').text(text1 + text2 + ' ' + item.value);
}

//Check for weapons and return its settings
function checkWeapon(num) {
    let square = $('.box[boxID = ' + num + ']');
    if (square.hasClass('weapon')) {
        if (square.hasClass('pinkBox')) {
            changeWeapon(num, 'pinkBox', pinkBox);
            return;
        }
        if (square.hasClass('yellowBox')) {
            changeWeapon(num, 'yellowBox', yellowBox);
            return;
        }
        if (square.hasClass('greenBox')) {
            changeWeapon(num, 'greenBox', greenBox);
            return;
        }
        if (square.hasClass('whiteBox')) {
            changeWeapon(num, 'whiteBox', whiteBox);
            return;
        }
        if (square.hasClass('redBox')) {
            changeWeapon(num, 'redBox', redBox);
            return;
        }
    }
}



/*--------------------------------------------------------------------------------------------
LOADING GAME
--------------------------------------------------------------------------------------------*/

//Add players to game
function addItem(eachPlayer, player) {
    let remainingSquares = squares;
    let boxes = $('.box');
    let empty = true;
    while (empty) {
        let item = getRandom(boardSize);
        let criteria;
        if (player === 1) {
            criteria = (item % 10 === 0);
        } else if (player === 2) {
            criteria = (item % 10 === 9);
        } else {
            criteria = (item % 10 !== 0 && item % 10 !== 9);
        }
        if (criteria && remainingSquares.includes(item)) {
            boxes.eq(item).addClass(eachPlayer);
            let index = remainingSquares.indexOf(item);
            remainingSquares.splice(index, 1);
            empty = false;
        }
    }
}

//Load Game
function loadGame() {
    game.createBoard();
    for (let i = 0; i < numObstacles; i += 1) {
        game.obstacles('obstacle');
    }

    redBox.add();
    whiteBox.add();
    greenBox.add();
    yellowBox.add();
    pinkBox.add();
    player1.add();
    player2.add();
    setPlayerData('#player-1', player1);
    setPlayerData('#player-2', player2);
    $('.player1').addClass('active');
}

attackButton.hide();
defendButton.hide();
playerContainerDiv.hide();
boardGameDiv.hide();
gameOverDiv.hide();

startButton.on('click', function () {
    playerContainerDiv.show();
    playerContainerDiv.css('display', 'flex');
    boardGameDiv.show();
    startGameDiv.hide();
    body.css("background-color", "white")
});


function getRandom(num) {
    return Math.floor(Math.random() * num);
}


loadGame();
movePlayer();


//The squares in the board will be based of x and y values; once the player's position is determined. convert those x y to square value
function getXYPosition(square) {
    return {
        x: (square) % 10
        ,
        y: Math.floor((square) / 10)
    }
}

const getPosition = (eachPlayer) => {
    return $(eachPlayer).attr('boxID');
};
let playerPosition = getPosition('.player1');
let oldPos = getXYPosition(playerPosition);

function getSquareValue(xPos, yPos) {
    return yPos * 10 + xPos;
}

function flipImage(playerClass){
    playerClass.addClass('flip-image')
}


/*--------------------------------------------------------------------------------------------
FIGHT
--------------------------------------------------------------------------------------------*/

//Show attack and defend buttons and hide message about active player.
function CanAttackAndDefend(playerActiveDiv, playerNotActiveDiv) {
    $(playerNotActiveDiv + ' .attack').show();
    $(playerNotActiveDiv + ' .defend').show();
    $(playerActiveDiv + ' .attack').hide();
    $(playerActiveDiv + ' .defend').hide();
    $(' .message1').hide();
    $(' .message2').hide();
}

//Print needed attack and hit messages
function message(playerActiveDiv, playerNotActiveDiv, playerActive, playerNotActive) {
    $(playerNotActiveDiv + ' .message').text(playerActive.name + ' just hit you  - ' + playerActive.damage + ' points');
    $(playerActiveDiv + ' .message').text('You just attacked');
}

//Show attack buttons only
function CanOnlyAttack(playerActiveDiv, playerNotActiveDiv) {
    $(playerNotActiveDiv + ' .attack').show();
    $(playerActiveDiv + ' .attack').show();
    $(playerNotActiveDiv + ' .defend').hide();
    $(playerActiveDiv + ' .defend').hide();
}

//When fighting, movement gets set to false.
function fight(newPos, oldPos) {

    if (newPos.y === oldPos.y && newPos.x <= oldPos.x + 1 && newPos.x >= oldPos.x - 1
        || newPos.x === oldPos.x && newPos.y <= oldPos.y + 1 && newPos.y >= oldPos.y - 1) {
        move = false;
        hover = false;
        $('.box').css('cursor', 'not-allowed');
        $(this).css('backgroundImage', '');

        for (let i = Math.min(oldPos.x, newPos.x); i <= Math.max(oldPos.x, newPos.x); i++) {
            let num = getSquareValue(i, oldPos.y);
            let square = $('.box[boxID = ' + num + ']');
            if (player1Active) {
                if (square.hasClass('player2')) {
                    let player1Square = $('.player1');
                    if($('.player2').attr('boxId') < player1Square.attr('boxId')){
                        flipImage(square);
                        flipImage(player1Square);
                    }
                    attacked = true;
                    attack(newPos, oldPos);
                    return;
                }

            } else {
                if (square.hasClass('player1')) {
                    let player2Square = $('.player2');
                    if($('.player1').attr('boxId') > player2Square.attr('boxId')){
                        flipImage(square);
                        flipImage(player2Square);
                    }
                    attacked = true;
                    attack(newPos, oldPos);
                    return;
                }
            }
        }
    }
}

//Update the scores after character is attacked or defended
function changeScore(playerNotActiveDiv, playerActive, playerNotActive) {
    if (defended) {
        playerNotActive.score = playerNotActive.score - 10 - playerActive.damage * .5;
        defended = false;
    } else {
        playerNotActive.score = playerNotActive.score - 10 - playerActive.damage;
    }

    $(playerNotActiveDiv + ' .score').text(playerNotActive.score);
}

//When attack
function attack() {
    if (attacked) {
        whoIsActive();
        changeScore(playerNotActiveDiv, playerActive, playerNotActive);
        CanAttackAndDefend(playerActiveDiv, playerNotActiveDiv);
        message(playerActiveDiv, playerNotActiveDiv, playerActive, playerNotActive);
        if (player1Active) {
            activeClass('.player1', '.player2');
            player1Defended = false;
            player1Active = false;
        } else {
            activeClass('.player2', '.player1');
            player2Defended = false;
            player1Active = true;
        }
        if (playerNotActive.score <= 0) {
            gameOver(playerActiveDiv, playerNotActiveDiv, playerActive, playerNotActive)
        }
    }
}
function activeClass(playerActiveClass, playerNotActiveClass){
    $(playerNotActiveClass).removeClass('active');
    $(playerActiveClass).removeClass('attack');
    $(playerNotActiveClass).addClass('attack');
}

//When defend
function defend() {
    defended = true;
    whoIsActive();
    if (player1Active) {
        activeClass('.player1', '.player2');
        player1Defended = true;
        player1Active = false;
    } else {
        activeClass('.player2', '.player1');
        player2Defended = true;
        player1Active = true;
    }
    if (player1Defended && player2Defended) {
        CanOnlyAttack(playerActiveDiv, playerNotActiveDiv)
    } else {
        CanAttackAndDefend(playerActiveDiv, playerNotActiveDiv)
    }
    $(playerActiveDiv + ' .message').text('you just defended');
}


//Attack and defend buttons
attackButton.on('click', function () {
    attack(newPos, oldPos);
    attacked = true;
});
defendButton.on('click', function () {
    defend(newPos, oldPos);
    defended = true;
});



/*--------------------------------------------------------------------------------------------
GAME OVER
--------------------------------------------------------------------------------------------*/

//When game is over, inform winner
function gameOver(playerActiveDiv, playerNotActiveDiv, playerActive, playerNotActive,) {
    $(playerNotActiveDiv + ' .score').text('0');
    $(playerActiveDiv + ' .message').text('You Win');
    $(playerNotActiveDiv + ' .message').text('You Lose');
    $(playerNotActiveDiv + ' .attack').hide();
    $(playerNotActiveDiv + ' .defend').hide();
    $('.box').remove();
    boardGameDiv.hide();
    gameOverDiv.show();
    playerNameDiv.css('color', '#fff');
    messageDiv.addClass('win');
    winnerDiv.text(playerActive.name + ' is the WINNER');
}


//When game over, reset game to start over
playAgainButton.on('click', function () {
    squares = [];
    messageDiv.removeClass('win');
    gameOverDiv.hide();
    boardGameDiv.show();
    player1 = new Player('Player 1', 100, 'player1', 1, '', 10);
    player2 = new Player('Player 2', 100, 'player2', 2, '', 10);
    player1Active = true;
    move = true;
    attacked = false;
    defended = false;
    player1Defended = false;
    player2Defended = false;
    $(playerNotActiveDiv + ' .message').text('');
    $(playerActiveDiv + ' .message').text('');
    playerNameDiv.css('color', '');
    $('.player-state').css('width', '75px').css('height', '75px');
    loadGame();
    playerPosition = getPosition('.player1');
    oldPos = getXYPosition(playerPosition);
    movePlayer();
});



